sql = import("mssql")

authKey = request.cookies['authKey']

if authKey ~= nil then
    connection = sql.createConnection(appconfig.connectionStrings["MyDatabase"])

    connection:open()
    username = connection:executeScalar("SELECT TOP 1 Username FROM Users WHERE AuthKey = @AuthKey", {  AuthKey = authKey })
    connection:close()

    if not isNullOrEmpty(username) then
        setItem("Username", username)
    end

end


